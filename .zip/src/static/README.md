# Falcon/src/static

**This isn't website stuff, this is simply a directory where shop items etc are stored.**
