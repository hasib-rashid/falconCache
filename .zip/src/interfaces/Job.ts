export interface Job {
	reaction: string;
	name: string;
	description: string;
	n?: boolean;
}
