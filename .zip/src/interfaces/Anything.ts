export interface Anything {
	[key: string]: any;
}
