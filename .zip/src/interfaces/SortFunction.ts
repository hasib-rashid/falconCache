export interface SortFunction {
	(a: object, b: object): number;
}
