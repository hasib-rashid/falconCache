export interface Item {
	name: string;
	description: string;
	price: number;
	id: string;
	unique?: boolean;
}
