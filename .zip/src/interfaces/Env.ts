export interface ENV {
    token: string;
    prefix: string;
    mongo_url: string;
    db: string;
    google_api: string;
    giphy_api: string;
    rapid_api: string;
}
