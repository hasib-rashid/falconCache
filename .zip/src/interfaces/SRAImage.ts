export interface SRAImage {
	link: string;
}
