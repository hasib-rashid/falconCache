import { RunFunction } from '../../interfaces/Command';

import NSFW from 'discord-nsfw'
const nsfw = new NSFW();

export const name = 'lewd'
export const category = 'nsfw'
export const description = 'NSFW Lewd'

export const run: RunFunction = async (client, message, args) => {
    message.channel.send(await nsfw.lewd())
}