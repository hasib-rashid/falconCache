import { RunFunction } from '../../interfaces/Command';

export const name = 'test'
export const category = 'owner'
export const description = 'Test Command for Owner'

export const run: RunFunction = async (client, message, args) => {

}